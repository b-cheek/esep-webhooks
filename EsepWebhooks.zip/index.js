exports.handler = async (event) => {
  console.log("Hello, world!");
};
